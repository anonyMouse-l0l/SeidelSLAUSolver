﻿namespace курсовая
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtEqs = new TextBox();
            txtVars = new TextBox();
            btnGenSLAU = new Button();
            txtConverg = new TextBox();
            btnSolve = new Button();
            btnAddEq = new Button();
            results = new TextBox();
            btnAddVar = new Button();
            btnSave = new Button();
            btnLoad = new Button();
            btnFileSolver = new Button();
            SuspendLayout();
            // 
            // txtEqs
            // 
            txtEqs.Location = new Point(12, 12);
            txtEqs.Name = "txtEqs";
            txtEqs.PlaceholderText = "Число уравнений";
            txtEqs.Size = new Size(158, 31);
            txtEqs.TabIndex = 0;
            // 
            // txtVars
            // 
            txtVars.Location = new Point(176, 12);
            txtVars.Name = "txtVars";
            txtVars.PlaceholderText = "Число неизвестных";
            txtVars.Size = new Size(170, 31);
            txtVars.TabIndex = 1;
            // 
            // btnGenSLAU
            // 
            btnGenSLAU.Location = new Point(352, 12);
            btnGenSLAU.Name = "btnGenSLAU";
            btnGenSLAU.Size = new Size(215, 31);
            btnGenSLAU.TabIndex = 2;
            btnGenSLAU.Text = "Сгенерировать";
            btnGenSLAU.UseVisualStyleBackColor = true;
            btnGenSLAU.Click += btnGenSLAU_Click;
            // 
            // txtConverg
            // 
            txtConverg.Location = new Point(12, 49);
            txtConverg.Name = "txtConverg";
            txtConverg.PlaceholderText = "Точность";
            txtConverg.Size = new Size(100, 31);
            txtConverg.TabIndex = 3;
            // 
            // btnSolve
            // 
            btnSolve.Location = new Point(118, 49);
            btnSolve.Name = "btnSolve";
            btnSolve.Size = new Size(139, 31);
            btnSolve.TabIndex = 4;
            btnSolve.Text = "Рассчитать";
            btnSolve.UseVisualStyleBackColor = true;
            btnSolve.Click += btnSolve_Click;
            // 
            // btnAddEq
            // 
            btnAddEq.Location = new Point(573, 12);
            btnAddEq.Name = "btnAddEq";
            btnAddEq.Size = new Size(224, 68);
            btnAddEq.TabIndex = 6;
            btnAddEq.Text = "Добавить недостающие уравнения";
            btnAddEq.UseVisualStyleBackColor = true;
            btnAddEq.Click += btnAddEq_Click;
            // 
            // results
            // 
            results.Location = new Point(12, 324);
            results.Multiline = true;
            results.Name = "results";
            results.ScrollBars = ScrollBars.Vertical;
            results.Size = new Size(1088, 120);
            results.TabIndex = 5;
            // 
            // btnAddVar
            // 
            btnAddVar.Location = new Point(803, 12);
            btnAddVar.Name = "btnAddVar";
            btnAddVar.Size = new Size(171, 68);
            btnAddVar.TabIndex = 8;
            btnAddVar.Text = "Добавить переменную";
            btnAddVar.UseVisualStyleBackColor = true;
            btnAddVar.Click += btnAddVar_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(1106, 324);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(124, 120);
            btnSave.TabIndex = 9;
            btnSave.Text = "Сохранить в файл";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(263, 49);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(304, 31);
            btnLoad.TabIndex = 10;
            btnLoad.Text = "Загрузить коэффициенты из файла";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnFileSolver
            // 
            btnFileSolver.Location = new Point(980, 12);
            btnFileSolver.Name = "btnFileSolver";
            btnFileSolver.Size = new Size(250, 68);
            btnFileSolver.TabIndex = 11;
            btnFileSolver.Text = "Решить систему из файла";
            btnFileSolver.UseVisualStyleBackColor = true;
            btnFileSolver.Click += btnFileSolver_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(1239, 480);
            Controls.Add(txtEqs);
            Controls.Add(txtVars);
            Controls.Add(btnGenSLAU);
            Controls.Add(txtConverg);
            Controls.Add(btnSolve);
            Controls.Add(btnAddEq);
            Controls.Add(results);
            Controls.Add(btnAddVar);
            Controls.Add(btnSave);
            Controls.Add(btnLoad);
            Controls.Add(btnFileSolver);
            Name = "Form1";
            Text = "Решение СЛАУ методом Зейделя";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.TextBox txtEqs;
        private System.Windows.Forms.TextBox txtVars;
        private System.Windows.Forms.Button btnGenSLAU;
        private System.Windows.Forms.TextBox txtConverg;
        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.Button btnAddEq;
        private System.Windows.Forms.TextBox results;
        private System.Windows.Forms.Button btnAddVar;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnFileSolver;
    }
}
